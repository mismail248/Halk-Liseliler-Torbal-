# Halkçı Liseliler - Torbalı (Şatafatlı Sürüm - Güncel Bilgiler)

Bu repo, Halkçı Liseliler Torbalı için hazırlanmış daha detaylı HTML/CSS site sürümüdür.

## Kullanım
1. `index.html` ve `assets/` klasörünü GitHub Pages veya Netlify'a yükleyin.
2. CHP logosunu `assets/chp-logo.svg` olarak ekleyin.
3. Galeri fotoğraflarını `assets/gallery-1.jpg`, `assets/gallery-2.jpg` vb. adlarla ekleyin.

## Yayına Alma (GitHub Pages)
- Repo ayarlarından **Pages** sekmesine gidin.
- Source: `main` branch seçin.
- 1-2 dakika içinde siteniz yayınlanır.

Instagram biyografinize çıkan linki ekleyebilirsiniz.
